This project is used by ODFDOM to generate dom layer elements and attributes.
